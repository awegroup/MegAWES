from sphinxsimulink.diagram.application import setup


