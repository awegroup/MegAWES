from pkg_resources import get_distribution
from sphinxsimulink import diagram
from sphinxsimulink.diagram.application import setup
